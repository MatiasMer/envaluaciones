package com.example.taskmaster;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;

public class NuevaNotaActivity extends AppCompatActivity {

    EditText editTextNota;
    Button btnGuardar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nueva_nota);

        editTextNota = findViewById(R.id.editTextNota);
        btnGuardar = findViewById(R.id.btnGuardar);

        btnGuardar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Guardar la nota en un Intent
                String nota = editTextNota.getText().toString();
                Intent intent = new Intent(NuevaNotaActivity.this, MarcarCumplidoActivity.class);
                intent.putExtra("nota", nota);
                startActivity(intent);
            }
        });
    }
}