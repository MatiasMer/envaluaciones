package com.example.taskmaster;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MarcarCumplidoActivity extends AppCompatActivity {

    TextView textViewNota;
    Button btnCumplido, btnNoCumplido;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_marcar_cumplido);

        textViewNota = findViewById(R.id.textViewNota);
        btnCumplido = findViewById(R.id.btnCumplido);
        btnNoCumplido = findViewById(R.id.btnNoCumplido);

        // Obtener la nota pasada desde la actividad anterior
        String nota = getIntent().getStringExtra("nota");
        textViewNota.setText(nota);

        btnCumplido.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MarcarCumplidoActivity.this, "Nota marcada como cumplida", Toast.LENGTH_SHORT).show();
            }
        });

        btnNoCumplido.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MarcarCumplidoActivity.this, "Nota marcada como no cumplida", Toast.LENGTH_SHORT).show();
            }
        });
    }
}